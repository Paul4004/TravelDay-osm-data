# TravelDay OSM-derived layer travelday-osm-2026-10-11.1

© OpenStreetMap contributors — ODbL 1.0.
https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/

Machine-readable segregated derivative layer, prepared 2026-10-11 for Коломна. See manifest.json for input hashes, source dataset, scope and coordinate order. No tiles, editorial reviews, official prose, photos, saved plans or private research corpus. Routing generated using GraphHopper 11.1 on OSM, not a verified visitor path. Posad line is an illustrative OSM street-centerline proposal. The ODbL data license applies to this layer; GraphHopper Apache 2.0 is the engine software license, not the data license.

This local package does not establish public data access. Repository and release URL are proposed only. Publication awaits separate owner approval. After approval, upload this exact archive and its SHA256SUMS/manifest to an immutable public release, verify anonymous download bytes/hash, and then set publicDataUrl in the app rights registry. Do not publish the private application repository or research corpus.
